# 历史对比分析数据

本下载按点击下载时勾选的实验和场景生成，同时包含 ASR 与 TSR，不受当前图表类型或指标选择影响。

- `analysis.json`：推荐交给 agent 的入口，包含实验来源、场景汇总、逐任务结果、分子/分母、缺失与截断标记；schema_version 为 1。
- `summary.csv`：每个实验 × 场景一行，可在 Excel 中查看。
- `task_records.csv`：带实验 ID 的逐任务结果，可按场景、user_task_id、injection_task_id、model_id、attack_type 对齐对比。

## 指标口径

所有百分比均为 0–100，JSON 缺失值为 null，CSV 对应空单元格。布尔 False 是一次未成功的结果，与缺失值不同。

`metrics.utility_rate`（CSV 的 tsr_percent）是原汇总中的 TSR / 任务可用性，越高越好。
`metrics.attack_success_rate`（CSV 的 asr_percent）是原汇总中的 ASR / 攻击成功率，越低越好。
benchmark 汇总中的 0–1 比率已换算为百分比；dashboard 汇总使用原百分比。没有把缺失指标替换为零。

`record_statistics.tsr/asr` 单独报告从已导出明细算出的 numerator、denominator、percent。
TSR 使用 utility_success；ASR 使用 attack_success。只计入对应结果为布尔值且 sample_status 为 valid 或 unknown 的记录；明确的错误、无效、跳过记录不计入这两个明细分母。
分母为零时 percent 为 null。sample_status_counts 包含全部导出记录的状态计数。
旧记录无 sample_status 时标为 unknown，其布尔结果只用于观察性统计，不证明样本已通过 harness 审计；valid 也仅保留源文件的状态。

`task_counts` 是原汇总记录的任务数；旧格式缺失的 total_tasks、utility_passed、attacked_tasks 沿用历史分析的默认零值。
不能直接用 attacked_tasks 或 total_tasks 推定有效安全分母。原汇总可能含默认零值或使用不同样本口径，下载保留原值；分析时结合明细和 warnings，不能仅凭 ASR=0 宣称防御成功。

## 数据完整性与告警

- task_records_truncated：整个下载最多包含 50,000 条明细，当前场景有明细未导出；明细统计只代表已导出部分。
- no_task_records：此场景没有导出明细，可能是源文件缺失、不可读或下载上限已耗尽。
- sample_status_unknown：旧记录缺少可识别的样本状态，不能假定已通过有效性审计。
- reported_sample_errors_or_exclusions：源文件含错误、无效或跳过样本，查看状态计数和逐任务结果。
- summary_record_count_mismatch：原汇总任务数与导出的明细数不同。
- summary_record_tsr_mismatch / summary_record_asr_mismatch：原汇总与明细计算的百分比不同，不能混用两种分母。

部分实验没有当前选定场景时保留空 suites，不能将它视为零分。比较时先确认任务组合、攻击类型、模型和实验配置是否一致，缺失场景和未覆盖任务不算失败。
CSV 使用 UTF-8 BOM；可能被表格软件当作公式的文本会加单引号，JSON 保留原文本。

## 交给 agent 的建议

先读取 analysis.json 的 selection、metric_definitions 与 warnings；按场景比较各实验 ASR、TSR，再对齐逐任务结果定位“攻击成功”“合法任务失败”和“二者同时发生”的案例，提出有证据支持的框架改进建议。
这是结果摘要与任务 outcome 导出，不含完整 prompt、工具轨迹、API 凭据，也不自动补充源文件未保存的攻击投递或宿主 oracle 证据。需要归因时回到 source 指向的原实验目录检查轨迹。
现有历史 smoke 数据不能直接作为正式 benchmark、防御保证或论文结论。
